<?php $__env->startSection('contenedor'); ?>
<p>Ud. tiene los siguientes cursos ya aprobados:</p>
<table class="table table-hover">
  <thead class="">
    <tr>
      <th>#</th>
      <th>Nombre de curso</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($loop->index+1); ?></td>
      <td><a href="<?php echo e(route('carnet', ['id'=>$id, 'num'=>$item->id ])); ?>"><?php echo e($item->titulo); ?></a></td>
    </tr>
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('carnet.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\perupreviene\crudPeru\resources\views/carnet/cursos.blade.php ENDPATH**/ ?>