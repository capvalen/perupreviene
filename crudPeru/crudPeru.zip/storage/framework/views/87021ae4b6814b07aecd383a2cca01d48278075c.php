<?php $__env->startSection('seccion'); ?>
<style>
.custom-file-input ~ .custom-file-label::after {
    content: "Buscar archivo";
}
</style>

<h1>Editar el cliente </h1>

<?php if(session('mensaje')): ?>
<div class="alert alert-success"><?php echo e(session('mensaje')); ?> puedes <a href="<?php echo e(route('index')); ?>">volver aquí</a> para visualizarlo</div>
<?php endif; ?>

<form action="<?php echo e(route('clientes.actualizar', $cliente->id)); ?>" method="POST">
  <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <div class="form-row">
      <div class="input-group">
        <input class="form-control my-2 <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="dni" placeholder="D.N.I.." value='<?php echo e(old( 'dni', $cliente->dni)); ?>' autocomplete="off">
        <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <input class="form-control my-2 <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="apellidos" placeholder="Apellidos y Nombres" value='<?php echo e(old('apellidos', $cliente->apellidos)); ?>' autocomplete="off">
      <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <input class="form-control my-2 <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="nombres" placeholder="Nombres" value='<?php echo e(old( 'nombres' , $cliente->nombres)); ?>' autocomplete="off">
      <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    

    <button class="btn btn-outline-warning  my-2" type="submit"><i class="icofont-save"></i> Actualizar datos</button>

<?php if(session('borrado')): ?>
<div class="alert alert-success"><?php echo e(session('borrado')); ?> </div>
<?php endif; ?>

</form>
<?php if($cliente->foto!=''): ?>
  <form action="<?php echo e(route('eliminarFoto', $cliente->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
      <div class="media">
        <img src="<?php echo e(url('subidas/'.$cliente->foto)); ?>" class="mr-3" height="150px">
        <div class="media-body">
          <h5 class="mt-0">Foto del empleado</h5>
          <button type="submit" class="btn btn-outline-danger"><i class="icofont-close"></i> Eliminar foto</button>
        </div>
      </div>
  </form>
<?php else: ?>
<?php if(session('fotoSubida')): ?>
<div class="alert alert-success"><?php echo e(session('fotoSubida')); ?> </div>
<?php endif; ?>
  <form action="<?php echo e(route('nuevaFoto', $cliente->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="input-group">
      <div class="custom-file">
        <input type="file" class="custom-file-input" id="inputGroupFile04" name="foto" aria-describedby="inputGroupFileAddon04">
        <label class="custom-file-label" for="inputGroupFile04">Escoger</label>
      </div>
      <div class="input-group-append">
        <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon04">Subir</button>
      </div>
    </div>
  </form>
  <?php endif; ?>
<h3 class="my-3">Cursos asignados:</h3>
<table class="table table-hover">
  <thead class="">
    <tr>
      <th>#</th>
      <th>Curso</th>
      <th>Emisión</th>
      <th>Vencimiento</th>
      <th>Código</th>
      <th>@</th>
    </tr>
  </thead>
  <tbody>
    <?php if(count($cursos)>0): ?>
    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($loop->index+1); ?></td>
      <td><a href="<?php echo e(route('carnet', ['id'=> $cliente->id, 'num'=> $curso->id] )); ?>"><?php echo e($curso->titulo); ?></a></td>
      <td><?php echo e($curso->pivot->emitido); ?></td>
      <td><?php echo e($curso->pivot->vencimiento); ?></td>
      <td><?php echo e($curso->pivot->codigo); ?></td>
      <td><button class="btn btn-danger btn-sm"><i class="icofont-close"></i></button></td>
    </tr>
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
        <td colspan="6">Aún no se asignó ningún curso</td>
      </tr>
    <?php endif; ?>
    
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\perupreviene\crudPeru\resources\views/clientes/editar.blade.php ENDPATH**/ ?>