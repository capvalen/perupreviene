<?php $__env->startSection('contenedor'); ?>
<p class="text-center mt-4">Gracias por ingresar a nuestra web, por favor ingresa tu D.N.I. para que puedas acceder:</p>

<?php if(session('noHay')): ?>
<div class="alert alert-danger role="alert">
  <?php echo e(session('noHay')); ?>

</div>
<?php endif; ?>

<form action="buscarDniFront" method="post">
<?php echo csrf_field(); ?>
<div class="col-6 mr-auto ml-auto d-flex flex-column ">
    <input type="text" name="dni" class="form-control my-3  ml-auto" autocomplete="off">
    <button class="btn btn-outline-secondary mr-auto ml-auto "><i class="icofont-search-1"></i> Buscar</button>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('carnet.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\perupreviene\crudPeru\resources\views/carnet/escoger.blade.php ENDPATH**/ ?>