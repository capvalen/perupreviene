<?php $__env->startSection('seccion'); ?>
<h1>Control administrativo</h1>
<div class=" d-none"> 
  <a href='<?php echo e(route('nuevoEmpleado')); ?>' class="btn btn-secondary mb-3" role="button">Crear nuevo cliente</a>
</div>

<h3>Últimos clientes registrados:</h3>

<?php if(session('borrado')): ?>
<div class="alert alert-danger"><?php echo e(session('borrado')); ?></div>
<?php endif; ?>
<?php if(session('mensaje')): ?>
<div class="alert alert-success"><?php echo e(session('mensaje')); ?></div>
<?php endif; ?>

<table class="table table-hover">
  <thead>
    <tr>
      <th>N°</th>
      <th>D.N.I.</th>
      <th>Apellidos</th>
      <th>Nombres</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($loop->index+1 /* $cliente->id */); ?></td>
      <td><?php echo e($cliente->dni); ?></td>
      <td><?php echo e(ucfirst($cliente->apellidos)); ?></td>
      <td><?php echo e(ucfirst($cliente->nombres)); ?></td>
      
      <td>
        <button type="button" class="btn btn-outline-success" onclick="abrirModal(<?php echo e($cliente->id); ?>)" ><i class="icofont-id"></i> </button>
        <a class="btn btn-outline-primary d-inline" href='<?php echo e(route('clientes.editar', $cliente)); ?>'><i class="icofont-edit"></i></a>
        <form class="d-inline" action="<?php echo e(route('clientes.eliminar', $cliente)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button class="btn btn-outline-danger" type="submit"><i class="icofont-trash"></i></button>
        </form>
      </td>
    </tr>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('aparte'); ?>
<form action="nuevoClienteCurso" method="post">
    <?php echo csrf_field(); ?>
  <!-- Modal -->
  <div class="modal fade" id="modalUnirCurso" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Asignación de curso</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>
            Seleccione el curso que desea agregar al cliente
          </p>
          <select name="idCursos" class="form-control">
            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->titulo); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <input type="text" name="idCliente" class="d-none" id="txtIdCurso">
          <label for="">Fecha de emisión:</label>
          <input type="date" name="fechaInicio" id="fechaInicio" class="form-control">
          <label for="">Fecha de expiración:</label>
          <input type="date" name="fechaFin" id="fechaFin" class="form-control">
          <label for="">Código:</label>
          <input type="text" name="codigo" id="" class="form-control">
          
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-outline-primary"><i class="icofont-label"></i> Crear credencial</button>
        </div>
      </div>
    </div>
  </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\perupreviene\crudPeru\resources\views/inicio.blade.php ENDPATH**/ ?>